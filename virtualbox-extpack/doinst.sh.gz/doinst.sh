GRP=`cat etc/group | grep vboxusers | head -n 1`
if [ "$GRP" = "" ] ; then
	chroot . groupadd vboxusers
fi

udevadm control --reload-rules

box_gid=`cat etc/group | grep vboxusers | cut -d ":" -f 3`

x=`cat etc/fstab | grep proc/bus/usb`
if [ ! -n "${x}" ];then
	echo "none /proc/bus/usb usbfs auto,busgid=${box_gid},busmode=0775,devgid=${box_gid},devmode=0664 0 0" >> etc/fstab
	echo "" >> etc/fstab
fi
                                        
