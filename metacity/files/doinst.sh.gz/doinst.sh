pkgname=_PKGNAME
chroot . /usr/sbin/gconfpkg --install ${pkgname}

